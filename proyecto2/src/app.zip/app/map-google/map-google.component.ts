import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-map-google',
  templateUrl: './map-google.component.html',
  styleUrls: ['./map-google.component.css']
})
export class MapGoogleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
