import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fontawesome',
  templateUrl: './fontawesome.component.html',
  styleUrls: ['./fontawesome.component.css']
})
export class FontawesomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
